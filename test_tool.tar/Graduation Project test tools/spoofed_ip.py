from scapy.all import *

def spoofed_request(target_ip, target_port, spoofed_ip, payload):
    # Create IP layer with spoofed source IP
    ip = IP(src=spoofed_ip, dst=target_ip)
    # Create TCP layer with random source port and SYN flag
    tcp = TCP(sport=RandShort(), dport=target_port, flags="S")
    syn = ip / tcp
    # Send SYN and wait for SYN-ACK
    syn_ack = sr1(syn, timeout=2)

    if syn_ack:
        # Complete handshake with ACK and send payload
        tcp = TCP(sport=syn_ack.dport, dport=target_port, flags="A", 
                  seq=syn_ack.ack, ack=syn_ack.seq + 1)
        push = ip / tcp / payload
        send(push)
        print("Request sent with spoofed IP:", spoofed_ip)
    else:
        print("No response from target.")

# Configuration
target_ip = "192.168.1.3"  # Replace with your WAF's IP
target_port = 80           # HTTP port (use 443 for HTTPS)
spoofed_ip = "45.138.74.1" # Replace with the malicious IP (e.g., "192.168.1.100")
payload = "GET / HTTP/1.1\r\nHost:192.168.1.3\r\n\r\n"  # Basic HTTP request

# Execute
spoofed_request(target_ip, target_port, spoofed_ip, payload)
