import socket
import time

host = "192.168.1.3"
port = 80

# Create socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((host, port))

# Send a GET request for a large file
request = f"GET /largefile HTTP/1.1\r\nHost: {host}\r\n\r\n"
sock.send(request.encode())

# Read response slowly
while True:
    data = sock.recv(1)  # Read 1 byte at a time
    time.sleep(1)  # Wait 1 second between reads
    if not data:
        break

sock.close()
