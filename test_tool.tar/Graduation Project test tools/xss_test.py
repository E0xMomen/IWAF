import requests

def test_waf_xss(target_url):
    # Define the XSS payload
    xss_payload = "<script>alert('XSS')</script>"
    
    # Append the payload to a query parameter
    url_with_payload = f"{target_url}?search={xss_payload}"
    
    # Send the GET request
    try:
        response = requests.get(url_with_payload)
        print(f"Status Code: {response.status_code}")
        print(f"Response Body: {response.text[:200]}...")
    except requests.exceptions.RequestException as e:
        print(f"Error sending request: {e}")

if __name__ == "__main__":
    # Replace with your WAF-protected URL
    target_url = "http://192.168.1.7"
    test_waf_xss(target_url)
